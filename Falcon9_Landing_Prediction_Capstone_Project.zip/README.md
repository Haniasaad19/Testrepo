# Falcon 9 First-Stage Landing Prediction — IBM Applied Data Science Capstone

This repository packages the capstone work required for the final presentation: data collection, web scraping, data wrangling, EDA with visualization and SQL, Folium mapping, Plotly Dash, and classification.

## Repository structure
- `notebooks/01_Data_Collection_API.ipynb` — SpaceX REST API collection
- `notebooks/02_Data_Collection_Web_Scraping.ipynb` — historical web scraping
- `notebooks/03_Data_Wrangling.ipynb` — cleaning and target construction
- `notebooks/04_EDA_Visualization.ipynb` — visual EDA
- `notebooks/05_EDA_SQL.ipynb` — SQL questions, queries and outputs
- `notebooks/06_Folium_Launch_Site_Analysis.ipynb` — geographic analysis
- `notebooks/07_Plotly_Dash_Dashboard.ipynb` — dashboard documentation
- `notebooks/08_Machine_Learning_Prediction.ipynb` — classification models
- `spacex_dash_app.py` — runnable Dash application
- `data/spacex_launch_dash.csv` — dashboard dataset snapshot supplied with the project
- `figures/` — supporting charts and map output

## Final presentation
`Falcon9_Landing_Prediction_Capstone.pdf`

## Repository
https://github.com/Haniasaad19/Testrepo

## Notes on reproducibility
The capstone presentation reports a 90-launch analytical dataset for the historical analysis and a separate dashboard dataset snapshot for the Dash lab. The notebooks preserve this distinction. Reported model/SQL values in the presentation are identified as reported results from the submitted analysis, while the included dashboard CSV is a smaller reproducible snapshot.

## Course alignment
The IBM Applied Data Science Capstone covers data collection, data wrangling, EDA, visualization, interactive dashboards, predictive classification, and reporting.
