import pandas as pd
from dash import Dash, dcc, html, Input, Output
import plotly.express as px

DATA = "data/spacex_launch_dash.csv"
df = pd.read_csv(DATA)

app = Dash(__name__)
site_options = [{"label":"All Sites","value":"ALL"}] + [
    {"label": s, "value": s} for s in sorted(df["Launch Site"].unique())
]
min_payload = int(df["Payload Mass (kg)"].min())
max_payload = int(df["Payload Mass (kg)"].max())

app.layout = html.Div([
    html.H1("SpaceX Launch Records Dashboard", style={"textAlign":"center"}),
    dcc.Dropdown(id="site-dropdown", options=site_options, value="ALL", clearable=False),
    dcc.RangeSlider(id="payload-slider", min=0, max=10000, step=500, value=[min_payload,max_payload],
                    marks={0:"0",2500:"2500",5000:"5000",7500:"7500",10000:"10000"}),
    dcc.Graph(id="success-pie-chart"),
    dcc.Graph(id="success-payload-scatter-chart")
])

@app.callback(Output("success-pie-chart","figure"), Output("success-payload-scatter-chart","figure"),
              Input("site-dropdown","value"), Input("payload-slider","value"))
def update(site, payload_range):
    d = df[df["Payload Mass (kg)"].between(payload_range[0], payload_range[1])].copy()
    if site != "ALL": d = d[d["Launch Site"] == site]
    if site == "ALL":
        p = df[df["class"] == 1].groupby("Launch Site").size().reset_index(name="Successful Landings")
        pie = px.pie(p, names="Launch Site", values="Successful Landings", title="Successful Landings by Site")
    else:
        d2 = d["class"].map({1:"Successful",0:"Unsuccessful"}).value_counts().reset_index()
        d2.columns=["Outcome","Count"]
        pie = px.pie(d2, names="Outcome", values="Count", title=f"Landing Outcome — {site}")
    d["Outcome"] = d["class"].map({1:"Successful",0:"Unsuccessful"})
    scatter = px.scatter(d, x="Payload Mass (kg)", y="class", color="Outcome",
                         title="Payload Mass vs. Landing Outcome")
    scatter.update_yaxes(tickvals=[0,1], ticktext=["Unsuccessful","Successful"])
    return pie, scatter

if __name__ == "__main__":
    app.run(debug=True)
